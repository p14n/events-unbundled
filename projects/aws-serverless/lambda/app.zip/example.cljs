(ns example
  (:require [handlers :as h]))
(defn handler [event _ctx]
  (js/console.log)
  (js/Promise.resolve
   (clj->js {:statusCode 200
             :body       (js/JSON.stringify
                          (clj->js (h/invite-customer
                                    {:event-notify-ch #(some-> % clj->js js/console.log)}
                                    (-> event
                                        (js->clj :keywordize-keys true)
                                        (update :type keyword))
                                    {})))})))
#js {:handler handler}